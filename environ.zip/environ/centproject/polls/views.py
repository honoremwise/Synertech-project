#from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return HttpResponse("<a href=http://localhost:3306/dashboard/>access</a>")

# Create your views here.
